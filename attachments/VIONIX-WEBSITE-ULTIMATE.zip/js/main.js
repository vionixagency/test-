
document.documentElement.classList.add('js');
document.documentElement.classList.add('page-ready');
document.addEventListener('DOMContentLoaded', () => {
  const header=document.querySelector('.site-header');
  const nav=document.querySelector('.nav');
  const toggle=document.querySelector('.nav-toggle');
  const mega=document.querySelector('.mega');
  const trigger=document.querySelector('[data-services-trigger]');
  const motion=document.querySelector('[data-motion-toggle]');

  const syncHeader=()=>header?.classList.toggle('scrolled', window.scrollY>24);
  syncHeader();
  window.addEventListener('scroll',syncHeader,{passive:true});

  const closeMega=()=>{if(!mega)return;mega.classList.remove('is-open');trigger?.setAttribute('aria-expanded','false');};
  const openMega=(force)=>{if(!mega)return;const next=force ?? !mega.classList.contains('is-open');mega.classList.toggle('is-open',next);trigger?.setAttribute('aria-expanded',String(next));};
  trigger?.addEventListener('click',()=>{openMega();});
  trigger?.addEventListener('mouseenter',()=>{if(window.matchMedia('(hover:hover)').matches && !window.matchMedia('(max-width:1020px)').matches)openMega(true);});
  mega?.addEventListener('mouseleave',()=>{if(!window.matchMedia('(max-width:1020px)').matches)closeMega();});
  document.addEventListener('click',(e)=>{if(mega && !mega.contains(e.target) && !trigger?.contains(e.target) && !window.matchMedia('(max-width:1020px)').matches)closeMega();});

  toggle?.addEventListener('click',()=>{
    const isOpen=toggle.getAttribute('aria-expanded')==='true';
    toggle.setAttribute('aria-expanded',String(!isOpen));
    toggle.setAttribute('aria-label',isOpen?'Open menu':'Close menu');
    nav?.classList.toggle('is-mobile-open',!isOpen);
    document.body.classList.toggle('nav-open',!isOpen);
  });

  document.addEventListener('keydown',(e)=>{
    if(e.key==='Escape'){
      closeMega();
      if(nav?.classList.contains('is-mobile-open')) toggle?.click();
    }
  });

  nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{if(nav.classList.contains('is-mobile-open'))toggle?.click();}));

  const reveals=document.querySelectorAll('.reveal,.reveal-group');
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(!reduced && 'IntersectionObserver' in window){
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
      if(entry.isIntersecting){entry.target.classList.add('in');observer.unobserve(entry.target);}
    }),{threshold:0.15});
    reveals.forEach(el=>observer.observe(el));
  }else{reveals.forEach(el=>el.classList.add('in'));}

  // Problem selector: one panel open at a time.
  const cards=[...document.querySelectorAll('.problem-card')];
  const panels=[...document.querySelectorAll('.problem-panel')];
  const placeholder=document.querySelector('.problem-placeholder');
  const openProblem=(key)=>{
    cards.forEach(card=>card.setAttribute('aria-expanded',String(card.dataset.problem===key)));
    panels.forEach(panel=>{panel.hidden=panel.dataset.problemPanel!==key;});
    if(placeholder)placeholder.hidden=true;
  };
  cards.forEach(card=>card.addEventListener('click',()=>openProblem(card.dataset.problem)));

  // FAQ / accordion groups.
  document.querySelectorAll('[data-accordion-group]').forEach(group=>{
    const buttons=[...group.querySelectorAll('[aria-controls]')];
    buttons.forEach(button=>button.addEventListener('click',()=>{
      const panel=document.getElementById(button.getAttribute('aria-controls'));
      const wasOpen=button.getAttribute('aria-expanded')==='true';
      buttons.forEach(other=>{
        other.setAttribute('aria-expanded','false');
        const target=document.getElementById(other.getAttribute('aria-controls'));
        if(target)target.hidden=true;
      });
      button.setAttribute('aria-expanded',String(!wasOpen));
      if(panel)panel.hidden=wasOpen;
    }));
  });

  // Ambient and bar animations pause when off-screen, hidden or manually paused.
  let paused=false;
  const setAnimatedState=(state)=>document.querySelectorAll('.flow,.bar').forEach(el=>{el.style.animationPlayState=state?'paused':'running';});
  motion?.addEventListener('click',()=>{
    paused=!paused;
    motion.setAttribute('aria-pressed',String(paused));
    motion.setAttribute('aria-label',paused?'Resume animations':'Pause animations');
    setAnimatedState(paused);
  });
  const ambient=document.querySelectorAll('.ambient');
  if('IntersectionObserver' in window){
    const ambientObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{entry.target.querySelectorAll('.flow').forEach(el=>el.style.animationPlayState=(entry.isIntersecting&&!paused)?'running':'paused');}));
    ambient.forEach(el=>ambientObserver.observe(el));
  }
  document.addEventListener('visibilitychange',()=>{if(document.hidden)setAnimatedState(true);else if(!paused)setAnimatedState(false);});

  // Interactive chart hover/focus dimming.
  document.querySelectorAll('.chart-wrap').forEach(chart=>{
    const bars=[...chart.querySelectorAll('.bar')];
    bars.forEach(bar=>{
      const activate=()=>bars.forEach(b=>b.style.opacity=b===bar?'1':'0.6');
      const clear=()=>bars.forEach(b=>b.style.opacity='');
      bar.addEventListener('mouseenter',activate);
      bar.addEventListener('focus',activate);
      bar.addEventListener('mouseleave',clear);
      bar.addEventListener('blur',clear);
    });
  });

  // Static GitHub Pages form: validate, then prepare a mailto message.
  document.querySelectorAll('[data-lead-form]').forEach(form=>form.addEventListener('submit',(e)=>{
    e.preventDefault();
    let ok=true;
    form.querySelectorAll('[required]').forEach(input=>{
      const message=input.parentElement.querySelector('small');
      const value=input.value.trim();
      if(!value){ok=false;if(message)message.textContent='This field is required.';}
      else if(input.type==='email' && !/^\S+@\S+\.\S+$/.test(value)){ok=false;if(message)message.textContent='Enter a valid email address.';}
      else if(input.type==='url'){try{new URL(value);}catch{ok=false;if(message)message.textContent='Enter a valid website URL.';}}
      else if(message)message.textContent='';
    });
    const status=form.querySelector('.form-status');
    if(!ok){status.textContent='Please check the highlighted fields.';status.className='form-status error';return;}
    const data=new FormData(form);
    const subject=encodeURIComponent(`Vionix Growth Audit — ${data.get('business')||'New enquiry'}`);
    const body=encodeURIComponent([
      `Name: ${data.get('name')||''}`,`Business: ${data.get('business')||''}`,`Email: ${data.get('email')||''}`,
      `Phone/WhatsApp: ${data.get('phone')||''}`,`Website: ${data.get('website')||''}`,`Goal / challenge: ${data.get('challenge')||''}`
    ].join('\n'));
    status.textContent='Opening your email app…';status.className='form-status success';
    window.location.href=`mailto:vionixsupport@gmail.com?subject=${subject}&body=${body}`;
  }));

  document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
});

/* VIONIX LIVING ENGINE — Canvas 2D marketing scenes + interaction */
(() => {
  const canvas = document.querySelector('.vx-living-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', {alpha:true});
  const scene = document.body.dataset.scene || 'home';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = matchMedia('(pointer:fine)');
  let paused = false, hidden = false, visible = true, raf = 0, last = performance.now(), scrollV = 0, lastScroll = scrollY;
  let w=0,h=0,dpr=1,t=0,quality=1,avg=16;
  const nodes=[], packets=[], bubbles=[], glyphs=[];
  const count = () => Math.max(8, Math.round((innerWidth < 700 ? 16 : 34) * quality * (navigator.hardwareConcurrency && navigator.hardwareConcurrency<=4 ? .65 : 1)));
  const resize=()=>{dpr=Math.min(devicePixelRatio||1,2);w=innerWidth;h=innerHeight;canvas.width=Math.floor(w*dpr);canvas.height=Math.floor(h*dpr);canvas.style.width=w+'px';canvas.style.height=h+'px';ctx.setTransform(dpr,0,0,dpr,0,0);};
  const seed=()=>{
    nodes.length=packets.length=bubbles.length=glyphs.length=0;
    const n=count();
    for(let i=0;i<Math.max(4,n/4);i++) nodes.push({x:.14+Math.random()*.72,y:.18+Math.random()*.64,r:2+Math.random()*2});
    for(let i=0;i<n;i++) bubbles.push({x:Math.random(),y:Math.random(),r:8+Math.random()*22,a:.07+Math.random()*.14,ph:Math.random()*7,anchor:Math.floor(Math.random()*Math.max(1,nodes.length))});
    for(let i=0;i<Math.max(5,n/5);i++) packets.push({a:Math.random(),edge:Math.floor(Math.random()*Math.max(1,nodes.length-1)),speed:.025+Math.random()*.035});
    for(let i=0;i<Math.max(6,n/3);i++) glyphs.push({x:Math.random(),y:Math.random(),s:5+Math.random()*7,r:Math.random()*6.28,v:(Math.random()-.5)*.08});
  };
  const colors=()=>{const h=getComputedStyle(document.documentElement).getPropertyValue('--h').trim()||158;return {ink:`hsl(${h} 45% 8% / .9)`,g:`hsl(${h} 74% 35% / .6)`,m:`hsl(${h} 70% 55% / .48)`,p:`hsl(${h} 55% 48% / .32)`,line:`hsl(${h} 55% 35% / .20)`};};
  const drawArrow=(c)=>{const base=h*.70, x=w*.76, dip=base-h*.04*Math.sin(t*.9), rise=t%7>5.2?Math.min(1,(t%7-5.2)/.8):0;ctx.strokeStyle=c.g;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(w*.58,base);ctx.lineTo(w*.68,dip);ctx.lineTo(w*.74,dip-h*.01);ctx.lineTo(x,dip-h*.10-rise*h*.18);ctx.stroke();ctx.beginPath();ctx.moveTo(x,dip-h*.10-rise*h*.18);ctx.lineTo(x-9,dip-h*.10-rise*h*.18+4);ctx.moveTo(x,dip-h*.10-rise*h*.18);ctx.lineTo(x-3,dip-h*.10-rise*h*.18+10);ctx.stroke();};
  const drawNetwork=(c)=>{const pts=nodes.map(n=>({x:n.x*w,y:n.y*h}));ctx.lineWidth=1;pts.forEach((p,i)=>{for(let j=i+1;j<pts.length;j++){const q=pts[j],dx=q.x-p.x,dy=q.y-p.y,dist=Math.hypot(dx,dy);if(dist<w*.38){ctx.strokeStyle=c.line;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke();}}});pts.forEach(p=>{ctx.fillStyle=c.g;ctx.beginPath();ctx.arc(p.x,p.y,2.2,0,Math.PI*2);ctx.fill();});packets.forEach(pk=>{const a=pts[pk.edge%pts.length],b=pts[(pk.edge+1)%pts.length];pk.a=(pk.a+pk.speed*(1+scrollV*.002)*.016)%1;const x=a.x+(b.x-a.x)*pk.a,y=a.y+(b.y-a.y)*pk.a;ctx.fillStyle=c.m;ctx.beginPath();ctx.arc(x,y,2.6,0,Math.PI*2);ctx.fill();});};
  const drawBubbles=(c)=>bubbles.forEach(b=>{const an=nodes[b.anchor%nodes.length]||{x:.5,y:.5};const tx=an.x+Math.sin(t*.16+b.ph)*.08,ty=an.y+Math.cos(t*.13+b.ph)*.08;b.x+=(tx-b.x)*.003;b.y+=(ty-b.y)*.003;const x=b.x*w,y=b.y*h;ctx.strokeStyle=`hsl(${(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--h'))||158)+8} 65% 48% / ${b.a})`;ctx.lineWidth=1;ctx.beginPath();ctx.arc(x,y,b.r,0,Math.PI*2);ctx.stroke();});
  const drawGlyphs=(c)=>glyphs.forEach(g=>{g.y-=.00015*(1+scrollV*.01);if(g.y<-.05)g.y=1.05;g.r+=g.v*.01;const x=g.x*w,y=g.y*h;ctx.save();ctx.translate(x,y);ctx.rotate(g.r);ctx.strokeStyle=c.p;ctx.lineWidth=1.2;ctx.beginPath();ctx.rect(-g.s/2,-g.s/2,g.s,g.s);ctx.moveTo(-g.s/2,0);ctx.lineTo(g.s/2,0);ctx.moveTo(0,-g.s/2);ctx.lineTo(0,g.s/2);ctx.stroke();ctx.restore();});
  const drawScene=()=>{ctx.clearRect(0,0,w,h);const c=colors();if(scene==='quiet'){drawBubbles(c);return;}if(scene==='seo'){drawNetwork(c);drawBubbles(c);return;}if(scene==='paid'){drawArrow(c);drawBubbles(c);return;}if(scene==='web'){drawGlyphs(c);drawBubbles(c);return;}if(scene==='ecommerce'){drawArrow(c);drawNetwork(c);return;}if(scene==='ai'){drawNetwork(c);drawGlyphs(c);return;}if(scene==='content'){drawGlyphs(c);drawBubbles(c);return;}drawArrow(c);drawNetwork(c);drawBubbles(c);drawGlyphs(c);};
  const frame=(now)=>{if(hidden||paused||reduce.matches){raf=0;return;}const dt=Math.min(50,now-last);last=now;t+=dt/1000;scrollV*=.92;drawScene();avg=avg*.95+dt*.05;if(avg>20&&quality>.45){quality*=.86;seed();}raf=requestAnimationFrame(frame);};
  const start=()=>{if(raf||hidden||paused||reduce.matches)return;last=performance.now();raf=requestAnimationFrame(frame);};
  const stop=()=>{if(raf){cancelAnimationFrame(raf);raf=0;}};
  addEventListener('resize',()=>{resize();seed();},{passive:true});
  addEventListener('scroll',()=>{scrollV=Math.abs(scrollY-lastScroll);lastScroll=scrollY;},{passive:true});
  document.addEventListener('visibilitychange',()=>{hidden=document.hidden;if(hidden)stop();else start();});
  reduce.addEventListener?.('change',()=>{if(reduce.matches)stop();else start();});
  document.querySelector('[data-motion-toggle]')?.addEventListener('click',e=>{paused=e.currentTarget.getAttribute('aria-pressed')==='true';if(paused)stop();else start();},{capture:true});
  const hero3d=document.querySelector('.vx-3d-scene');
  if(hero3d&&finePointer.matches&&!reduce.matches){hero3d.addEventListener('pointermove',e=>{const r=hero3d.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;hero3d.querySelector('.vx-3d-orbit').style.transform=`rotateX(${(-y*10).toFixed(2)}deg) rotateY(${(x*12).toFixed(2)}deg) translateZ(8px)`;});hero3d.addEventListener('pointerleave',()=>hero3d.querySelector('.vx-3d-orbit').style.transform='');}
  resize();seed();if(!reduce.matches) requestIdleCallback?.(start) || setTimeout(start,250);
})();
